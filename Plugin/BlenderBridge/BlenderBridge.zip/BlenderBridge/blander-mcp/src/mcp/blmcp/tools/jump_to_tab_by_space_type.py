# SPDX-FileCopyrightText: 2026 Blender Authors
#
# SPDX-License-Identifier: GPL-3.0-or-later

# pylint: disable=C0114  # See tool doc-string.

__all__ = (
    "register",
)

from blmcp.tools_helpers import (
    toolcode_format_call,
    toolcode_load_from_filepath,
    toolcode_wrap_with_calling_convention,
)
from blmcp.tools_helpers.connection import send_code
from blmcp.tools.jump_to_tab_by_space_type_toolcode import Params
from mcp.server.fastmcp import FastMCP  # pylint: disable=import-error,no-name-in-module
from mcp.types import ToolAnnotations  # pylint: disable=import-error,no-name-in-module

_TOOL_CALL = toolcode_wrap_with_calling_convention(toolcode_load_from_filepath(__file__))


def register(mcp: FastMCP) -> None:
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Switch to Matching Workspace",
            destructiveHint=True,
        )
    )
    def jump_to_tab_by_space_type(
        space_type: str,
        allow_edits: bool = False,
    ) -> dict[str, object]:
        """
        Switch to a workspace whose main area matches *space_type*.

        If *allow_edits* is True and no matching workspace exists, a new one
        is created by duplicating the current workspace.
        """
        p = Params(space_type=space_type, allow_edits=allow_edits)
        code = toolcode_format_call(_TOOL_CALL, p)
        return send_code(code, strict_json=True)
